.
jQuery(".teaminfo").click(function () {
    var idofinfo = jQuery(this).attr("id");
    console.log(idofinfo);

    var result = idofinfo.split("_");
    var toshopopup = "teamInfoModal" + result[1];
    var tohidepopup = "teamInfoModal" + result[1];

    jQuery("#" + toshopopup).css({ display: "block" });
  });

  jQuery(".close").click(function () {
    var idofpopup = jQuery(this).attr("id");
    console.log(idofpopup);

    var result = idofpopup.split("_");
    var tohidepopup = "teamInfoModal" + result[1];

    jQuery("#" + tohidepopup).css({ display: "none" });
  });


