<?php
/* Mailchimp for contact us page */
add_action("wp_ajax_mailchimp_addsubscriber", "mailchimp_addsubscriber_callbak");
add_action("wp_ajax_nopriv_mailchimp_addsubscriber", "mailchimp_addsubscriber_callbak");
function mailchimp_addsubscriber_callbak(){
  
extract($_POST);
  
    $to             = get_field('to_subscription_email','option');
    $from           = get_field('from_subscription_email','option');
    $headers        = array('Content-Type: text/html; charset=UTF-8');
    $subjet         = get_field('subscription_subject','option');
    $message_body   = get_field('message_body','option');
    
    $mail_replaced = str_replace( 
                    array(
                        '{name}',
                        '{email}',
                        '{company}',
                        '{responsibility}',
                        '{phone}',
                        '{interest_area}',
                        '{message}'
                         ), 

                    array(
                        sanitize_text_field($name),
                        sanitize_text_field($email),
                        sanitize_text_field($company),
                        sanitize_text_field($responsibility),
                        sanitize_text_field($phone),
                        sanitize_text_field($interestArea),
                        sanitize_text_field($message)
                    ),
                    $message_body
                );
    
     wp_mail($to,$subject,$mail_replaced);
    




 if( $checkbox ) {

$apiKey =  get_field('api_key','option');
$listId =  get_field('list_id','option');
$memberId = md5(strtolower($email));
$dataCenter = substr($apiKey,strpos($apiKey,'-')+1);
$url = 'https://' . $dataCenter . '.api.mailchimp.com/3.0/lists/' . $listId . '/members/' . $memberId;

$json = json_encode([
    'email_address' => $email,
    'status'        => 'subscribed', 
	    'merge_fields'  => [
	        'NAME' 		=> $name,
			'COMPANY' 	=> $company,
			'RESPONSIBI'=> $responsibility,          
			'PHONE' 	=> $phone,  
			'INTERESTA'	=> $interestArea,         
			'MESSAGE' 	=> $message 
	    ]
]);

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_USERPWD, 'user:' . $apiKey);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, $json);                                                                                                                 

$result   = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

print_r($result);
}

die;
}