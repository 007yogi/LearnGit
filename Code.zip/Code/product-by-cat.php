            <!-- finish enquiry-block --> 
            
          </div>
          <div class="centering tab-centering"> 
            <!-- begin tab-block -->
            <div id="horizontalTab" class="tab-block">
              <ul class="reless resp-tabs-list">
			  
<?php   
$args = array(
		'post_type' => 'product',
		'orderby' => 'name',
		'parent' => 83,      //parent cat id
		'taxonomy' => 'product_cat'
		);
$categories = get_categories( $args );    // here we get child cate of parent cate_id is- 83
//print_r ($categories);
foreach ( $categories as $category ) {
	   $category->name;
	   $category->slug;
//echo  $category->name;
?>
			  
<li><a href="javascript:void(0);"><?php echo  $category->name;?></a></li>
				
<?php } ?> 	               
              </ul>
              <div class="tabs resp-tabs-container">	  
 
<?php   
$args = array(
		'post_type' => 'product',
		'orderby' => 'name',
		'parent' => 83,      //parent cat id
		'taxonomy' => 'product_cat'
		);
$categories = get_categories( $args );
//print_r ($categories);
foreach ( $categories as $category ) {
	   $category->name;
	   $category->slug;
//echo  $category->name;


 $arg = array(
			'post_type' => 'product',
			'order' => 'ASC',
			'showposts' => -1,
			'tax_query' =>array(
				array(
					'taxonomy'=>'product_cat',
					'field' =>'slug',
					'terms' => $category->slug
				),
			),
		);	
$wp_query = new WP_Query($arg);
?>
				
                <div class="accr">	
				
		<?php 
		global $product;
		
		if($wp_query->have_posts()) : while($wp_query->have_posts()) : $wp_query->the_post();
		$img = wp_get_attachment_url(get_post_thumbnail_id(),array());
		$regular_price = get_post_meta( get_the_ID(), '_regular_price', true);
		$sale_price = get_post_meta( get_the_ID(), '_sale_price', true);
		//echo $img;
		?>
				
                  <div class="box">
                    <div class="box1">
                      <div class="innerbox"> <img src="<?php echo $img;?>" alt="Chair"/> </div>
                      <div class="boxcontant">
                        <h3><a href="#"><?php the_title();?></a></h3>
                        <span class="name">Onze prijs</span> <span class="price">€ <?php echo $sale_price;?></span> <span class="old-price">Adviesprijs: € <?php echo $regular_price;?></span></div>
						
<div class="boxcontant boxcontant6"> <span class="green"><?php echo $product->is_in_stock() ? 'InStock' : 'OutOfStock'; ?></span> <span class="gray"><?php if ($product->is_in_stock()){?>Voor 18:00 besteld, morgen in huis<?php } else { ?>Het product is tijdelijk niet op voorraad<?php } ?></span> </div>
                    </div>
<?php 
echo apply_filters( 'woocommerce_loop_add_to_cart_link',
    sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" class="anchor %s product_type_%s"><span>%s</span></a>',
        esc_url( $product->add_to_cart_url() ),
        esc_attr( $product->id ),
        esc_attr( $product->get_sku() ),
        $product->is_purchasable() ? 'add_to_cart_button' : '',
        esc_attr( $product->product_type ),
        esc_html( $product->add_to_cart_text() )	
    ),
$product );
?>
                    <!--<a class="anchor" href="#"><span>In winkelwagen</span></a>-->
				  </div>			  
 <?php endwhile;endif;wp_reset_query(); ?>
 
                  <div class=" clear"></div>
                  <div class="anchor all-anchor"> <a href="#">Bekijk alle producten
                    <p>text</p>
                    </a> </div>
                </div>				
<?php } ?>					
               
              </div>
            </div>
            <!-- finish tab-block --> 