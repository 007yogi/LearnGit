<?php 
	/* Template Name: Generic Case Study(Work) Page */ 

get_header(); ?>

<!--Start content-->
<div class="case-study-wrap work-generic-page">

    <!--Start Banner-->
    <?php 
        $banner_img = get_field('banner');
        $id = $_GET['id'];
    ?>
    <div class="case-study-banner">
        <section class="inner-banner " style="background-image: url(<?php echo $banner_img; ?>);">
            <a href="<?php echo get_home_url(); ?>/work/#case-study<?php echo $id; ?>"><i class="close-icon"></i></a>
        </section> 
    </div>
    <!--end Banner-->


    <?php if( have_rows('generic_page_section') ): ?>
        <?php while( have_rows('generic_page_section') ): the_row(); ?>

            
         <!-- campaign section -->
         <?php if( get_row_layout() == 'campaign_section' ): ?>
                 
            <?php 
            $campaign_title = get_sub_field('title');
            $campaign_logo = get_sub_field('logo');
            ?>
                  
            <?php if ($campaign_title){ ?>
            <section class="top-content py-100">
                <div class="container">
                   <h2 class="pb-50"><?php echo $campaign_title; ?></h2>
                    <div class="four-column">
                          <?php if ($campaign_logo){ ?>
                        <div class="four-column__box" data-aos="fade-up">
                            <div class="log-box">
                                <img src="<?php echo $campaign_logo['url']; ?>" alt="<?php echo $campaign_logo['alt']; ?>">
                            </div>
                        </div>
                        <?php } ?>

                         <?php  
                         $i =3; 
                        if(have_rows('campaign_values')):
                        while(have_rows('campaign_values')):
                        the_row();
                        $heading = get_sub_field('heading');
                        $copy = get_sub_field('copy');
                        ?>
                        <div class="four-column__box" data-aos="fade-up" data-aos-delay="<?php echo $i;?>00">
                            <h3><?php echo $heading; ?></h3>
                            <p><?php echo $copy; ?></p>
                        </div>

                        <?php $i+=2; endwhile; endif ;?>
                    </div>
                </div>  
            </section>
            <?php } ?>
            
        <?php endif; ?>
        <!-- end campaign section -->


         <!-- featured image -->
        <?php if( get_row_layout() == 'featured_image' ): ?>
            
            <section class="features pb-100">
                <div class="container" data-aos="fade-up">
                    <div class="features__img">
                         <img src="<?php echo get_sub_field('image')['url']; ?>" alt="<?php echo get_sub_field('image')['alt']; ?>">
                    </div>
                    <p class="case-text-light"><?php echo get_sub_field('text') ?></p>
                </div>
            </section>

        <?php endif; ?>
        <!-- featured image -->

        <!-- featured video -->
        <?php if( get_row_layout() == 'featured_video' ): ?>
                
            <!--Start VIDEO-->
             <?php 
            $video_url = get_sub_field('video_url');
            $video_image = get_sub_field('video_poster');
            $video_text = get_sub_field('text');
            ?>
            <?php if ($video_url){ ?>
            <section class="video pb-100">
                <div class="container" data-aos="fade-up">
                    <div class="video-player-wrap">
                        <iframe src="<?php echo $video_url; ?>" allow="autoplay" width="640" height="360" frameborder="0" webkitallowfullscreen="" mozallowfullscreen="" allowfullscreen=""></iframe>
                        <div class="video-poster">
                            <img src="<?php echo $video_image['url']; ?>" alt="<?php echo $video_image['alt']; ?>">
                            <i class="video-play-icon fa fa-play-circle"></i>
                        </div>
                    </div>
                     <?php if ($video_text){ ?>
                    <p class="case-text-light"><?php echo $video_text; ?></p>
                     <?php } ?>
                </div>
            </section>
            <?php } ?>
            <!--end VIDEO-->

        <?php endif; ?>
        <!-- End featured video -->


        <!-- Campaign Info -->
        <?php if( get_row_layout() == 'campaign_info' ): ?>

        
            <section class="second-content pb-100">
                <div class="container">
                    <div class="two-column-sec aos-init aos-animate" data-aos="fade-up"> 
                        <div class="two-column-sec__box-left">
                            <h2 data-aos="fade-in" class="aos-init aos-animate"><?php echo get_sub_field('heading'); ?></h2>
                        </div>
                        <div class="two-column-sec__box-right aos-init aos-animate" data-aos="fade-up">
                            <p><?php echo get_sub_field('content_copy'); ?></p>
                        </div>
                    </div>
                </div>
            </section>


        <?php endif; ?>
        <!-- Campaign Info -->


        <!-- Radio Section -->
        <?php if( get_row_layout() == 'radio_section' ): ?>
        <?php $audio_text = get_sub_field('audio_text');?>
        <section class="pb-100">            
            <div class="container">
                <?php                     
                    while(have_rows('audio')):
                            the_row();
                            $audio_file = get_sub_field('audio_file');
                    ?>
                <div class="audio-wrap">
                    <audio controls src="<?php echo $audio_file['url']; ?>" initaudio="false"></audio>
                </div>
                <?php  endwhile; ?>
                <p class="case-text-light"><?php echo $audio_text; ?></p>
            </div>
        </section>
        <?php endif; ?>
        <!-- End Radio Section -->


        <!--Start Gallery Section -->
        <?php if( get_row_layout() == 'gallery_section' ): ?>
        <section>
            <div class="container">
            <?php  
            $social_media_text = get_sub_field('social_media_text');
            if(have_rows('social_media')): ?>   
                <div class="social-media-post" data-aos="fade-up">
                    <?php                     
                    while(have_rows('social_media')):
                    the_row();
                    $social_media_image = get_sub_field('social_media_image');
                    ?>
                    <div class="social-media-post__img">
                        <img src="<?php echo $social_media_image['url']; ?>" alt="<?php echo $social_media_image['alt']; ?>">
                    </div>
                <?php  endwhile; ?>                    
                </div>
            <?php  endif ;?>
            <?php  if ($social_media_text){ ?>
                <p class="case-text-light"><?php echo $social_media_text; ?></p>
               <?php }  ?>  

            </div>
        </section>
        <?php endif; ?>
        <!--End  Gallery Section -->





        <!--Start Videos-->    
        <?php if( get_row_layout() == 'horizontal_gallery' ): ?> 
        <?php 
        $videos_text = get_sub_field('videos_text');
            if(have_rows('videos')): ?>
            <div id="horizontalVidGallery1" class="horizontal-gallery-video video container-fluid right-flow">              
                <div id="vidGallerySlideWrap1" class="gallery-slide-wrap"> 
                    <?php                    
                    while(have_rows('videos')):
                    the_row();
                    $video_url = get_sub_field('video_url');
                    $video_image = get_sub_field('video_image');
                    ?>
                        <div class="video-player-wrap video-panel">
                            <div class="vid-content">
                                <iframe src="<?php echo $video_url; ?>" allow="autoplay" width="640" height="360" frameborder="0" webkitallowfullscreen="" mozallowfullscreen="" allowfullscreen=""></iframe>
                                <div class="video-poster">
                                    <img src="<?php echo $video_image['url']; ?>" alt="<?php echo $video_image['alt']; ?>">
                                    <i class="video-play-icon fa fa-play-circle"></i>
                                </div>
                            </div>
                        </div>
                    <?php  endwhile; ?>                  
                    
                </div>                
                  <?php if ($videos_text){ ?>
                    <div class="text-sec">
                         <p class="case-text-light"><?php echo $videos_text; ?></p>
                    </div>
                <?php } ?>
            </div>            
           <?php endif ; ?>
        <?php endif; ?>
        <!--end Videos-->


        <!--Start BILLBOARD-->
         <?php if( get_row_layout() == 'billboard_section' ): ?> 
         <?php
         $full_width_image = get_sub_field('full_width_image');
         $full_width_image_text = get_sub_field('full_width_image_text');
         if ($full_width_image){ ?>
        <section class="py-100" data-aos="fade-up">         
            <div class="full-img">
                <img src="<?php echo $full_width_image['url']; ?>" alt="<?php echo $full_width_image['alt']; ?>">
            </div>
            <?php  if ($full_width_image_text){ ?>
            <div class="container">
                <p class="case-text-light"><?php echo $full_width_image_text; ?></p>
            </div>
            <?php }  ?>             
        </section>
        <?php } ?>  
        <?php endif; ?>
        <!--End BILLBOARD-->



                <!--start Website-->   
        <?php if( get_row_layout() == 'website_section' ): ?>            
        <?php 
        $website_image = get_sub_field('website_image');
        $website_text = get_sub_field('website_text');
        if ($website_image){  ?>
        <section class="pt-100">
            <div class="container" data-aos="fade-up">
                <img src="<?php echo $website_image['url']; ?>" alt="<?php echo $website_image['alt']; ?>">
                <div class="link-with-heading">
                    <p class="case-text-light ss-text"> <?php echo $website_text; ?></p>
                </div>
            </div>
        </section>
        <?php } ?>
        <?php endif; ?>
        <!--end Website-->


        <!-- view next case study section -->
        <?php if( get_row_layout() == 'next_case_study_section' ): ?>    
        <div class="view-next-case-study text-center">
            <a href="<?php echo get_sub_field('view_next_case_study_link') ?>" class="btn btn-red">View Next Case Study</a>
        </div>
        <?php endif; ?>
        <!-- view next case study section -->

        <?php endwhile; ?>
    <?php endif; ?>

</div>
<!--End Start content-->

<?php get_footer();?>