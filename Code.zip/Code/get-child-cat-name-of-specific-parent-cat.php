<?php
/* this function in function.php*/
function getcategorynameallinpost($postid){

// Get terms for post
 $terms = get_the_terms( $postid, 'lesson-cat' );
/* echo "<pre>";
 print_r($terms);die;*/

 // Loop over each item since it's an array
 if ( $terms != null ){
 	foreach( $terms as $term ) {

 		if( $term->slug =='elementary' ){
 			continue;
 		}

 		$categor .= $term->name.', '; 

        }

     return rtrim($categor, ', ');

    }


}
?>

<div id="<?php echo $slug;?>" class="colmn-section">

    <?php if( $query->have_posts() ) : while( $query->have_posts() ) {

         $query->the_post();

        $child_cat =  getcategorynameallinpost(get_the_ID());   
    ?>

    

    <a href="<?php the_permalink(); ?>" class="colmn-box">

        <?php  $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'custom-blog-img-size');  ?>

        <figure>
            <img src="<?php echo $featured_img_url;?>">
        </figure>
        <p><?php the_title(); ?></p>

        <?php if($slug == 'elementary') { ?>
            <p><?php echo $child_cat;?></p>
        <?php } ?>

    </a>

    <?php } endif;  wp_reset_query();  ?>
    
</div>

