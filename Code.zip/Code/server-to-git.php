1:  ssh -i iskpro_final.pem ubuntu@34.230.181.212
2:  chmod 0400 iskpro_final.pem  (For change permission)
3:  cd /var/www/html
4:  pwd
