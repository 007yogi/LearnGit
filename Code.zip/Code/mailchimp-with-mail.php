<?php
jQuery('#checkboxOneInput').change(function(){
     if(jQuery(this).attr('checked')){
          jQuery(this).val('true');
     }else{
          jQuery(this).val('false');
     }
});

/* Mailchimp for contact us page */

jQuery('#submit-btn').click(function (event) {
        event.preventDefault();

    jQuery.ajax({
        type: 'POST',
        url: object.ajaxurl,
        data: {
            action: 'mailchimp_addsubscriber',           
              name              : jQuery('#contactName').val(),  
              email             : jQuery('#contactEmail').val(),  
              company           : jQuery('#contactCompany').val(),  
              responsibility    : jQuery('#contactResponsibility').val(),  
              phone             : jQuery('#contactPhone').val(),  
              interestArea      : jQuery('#interestArea :selected').val(),  
              message           : jQuery('#contactMessage').val(),
              checkbox          : jQuery('#checkboxOneInput').val()
        },

        success: function (data) {

      console.log(data);
      
            var responsearray = JSON.parse(data);

            if (responsearray.status == 'subscribed') {

                 jQuery("#contact-form")[0].reset();
                 jQuery('#contact_succes_msg').html("Thanks for subscribing.");

            } else {

            }
            //jQuery('#es_txt_email_pg').val('');
        },
         error: function (MLHttpRequest, textStatus, errorThrown) {
        }
    });

});

/* End Mailchimp for contact us page */





/////////////////////////////////////////////////////////////////////////////////////

?>

Html ofcontact form

        <form id="contact-form" action="">

          <div class="row">
            <div class="col-md-6">
              <input type="text" id="contactName" name="contact-name" placeholder="Name" required="required">
            </div>
            <div class="col-md-6">
              <input type="text" id="contactEmail" name="contact-email" placeholder="Email" required="required">
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <input type="text" id="contactCompany" name="contact-company" placeholder="Company/Organization">
            </div>
            <div class="col-md-6">
              <input type="text" id="contactResponsibility" name="contact-role" placeholder="Area of Responsibility">
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <input type="text" id="contactPhone" name="contact-phone" placeholder="Phone" required="required">
            </div>
            <div class="col-md-6">
               <select name="cars" id="interestArea">
                 <option value="" disabled selected>I’m interested in...</option>
                 <option value="A workshop for my organization">A workshop for my organization</option>
                 <option value="A workshop for myself">A workshop for myself</option>
                 <option value="Data Storytelling Assessment">Data Storytelling Assessment</option>
                 <option value="Discussing mentoring/consulting">Discussing mentoring/consulting</option>
                 <option value="Booking for a speaking event">Booking for a speaking event</option>
                 <option value="Other topic">Other topic</option>
               </select> 
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <textarea id="contactMessage" name="form-message" rows="3" width="100%" placeholder="Message"></textarea> 
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <p><input type="checkbox" value="true" id="checkboxOneInput" name="" /> Sign me up for the Storylytics e-newsletter</p>
              <p>You can <a href="mailto:laura.warren@storylytics.ca?subject=Unsubscribe%20Request&body=Kindly%20remove%20my%20email%20address%20from%20your%20mailing%20list.%20Thank%20you.">unsubscribe</a> at any time (but we don’t think you’ll want to.)</p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <input type="submit" name="submit" id="submit-btn" value="Submit">
               <div id = "contact_succes_msg"></div>
            </div>
          </div>

        </form>

/////////////////////////////////////////////////////////////////////