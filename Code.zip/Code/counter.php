                    <?php                       
                        $args = array('post_type'=>'faq','showposts'=>-1);
                        query_posts($args);
 
                        $counter = 1;
                        $j =1;
                        if(have_posts()) : $i=1; while(have_posts()) : the_post();
                         
                        if($counter%4 ==1){
                    ?>
 
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
 
                         
                        <div class="panel-group" id="<?php if($j%2 == 1){ echo 'question';} else { echo 'answer';} ?>"> 
                         
 
                        <?php } ?>
 
                                                         
<div class="panel panel-default">
 
    <div class="panel-heading" data-toggle="collapse" data-parent="#<?php if($j%2 == 1){ echo 'question';} else { echo 'answer';} ?>" href="#collapse<?php echo $i;?>">
 
        <h3 class="panel-title"><i class="fa fa-chevron-down" aria-hidden="true"></i> <?php the_title();?></h3>
    </div>
 
    <div id="collapse<?php echo $i;?>" class="panel-collapse collapse">
        <div class="panel-body"><?php the_content();?></div>
    </div>
     
</div> 
                             
 
                        <?php 
                            if($counter%4 ==0) 
                            { 
                                echo '</div>';                          
                                echo '</div>';
                                $j++;
                            }
 
                        $counter++;
 
                        ?>
 
                        <?php $i++; endwhile; endif; wp_reset_query(); ?>  
                </div>
 
            </div>