<?php
/*function abc($a,$b){
	retrun (a*b);
}
add_action('xyz','abc',10,2);*/


$value = do_action( 'xyz',2,2);



function example_callback( $string, $arg1, $arg2 ) {
  
    return $string;
}
add_filter( 'example_filter', 'example_callback', 10, 3 );


$value = apply_filters( 'example_filter', 'filter me', $arg1, $arg2 );