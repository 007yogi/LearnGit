$themecsspath = get_template_directory().'/app/css/style.css';
 $style_ver    = filemtime( $themecsspath );

wp_enqueue_style( 'stylecss',   get_template_directory_uri().'/app/css/style.css' , array(), $style_ver );

////////////////////////////////////////////////////////


$themecsspath = get_template_directory().'/App/css/style.min.css';
	$style_ver    = filemtime( $themecsspath );

wp_enqueue_style( 'stylemincss', get_template_directory_uri().'/App/css/style.min.css', array(), $style_ver  );