<?php
/*Physician Registration*/
add_action('wp_ajax_register_physician','register_physician_callback');
add_action('wp_ajax_nopriv_register_physician','register_physician_callback');
function register_physician_callback(){

    extract($_POST);

    $user_name = sanitize_text_field($_POST['email']);

    if ( username_exists( $user_name ) != false ){
        echo json_encode(array('flag'=>'failure','message'=>'The username already exists.'));
    }
    elseif( email_exists($user_name)   != false ){
        echo json_encode(array('flag'=>'failure','message'=>'The email already exists.'));
    }else{


    $user_id = wp_create_user( 
                    sanitize_text_field($_POST['email'] ), 
                    '',
                    sanitize_text_field($_POST['email'] ) 
                );

    $user = new WP_User($user_id); 

    $user->set_role('physician');
    update_user_meta( $user_id, 'user_status', 0 );

    update_user_meta( $user_id, 'jobtitle',    sanitize_text_field($_POST['jobtitle'])  );
    update_user_meta( $user_id, 'facility',    sanitize_text_field($_POST['facility']) );
    update_user_meta( $user_id, 'phonenumber', sanitize_text_field($_POST['phonenumber']) );

    update_user_meta( $user_id, 'first_name', sanitize_text_field($_POST['firstname'] ) );
    update_user_meta( $user_id, 'last_name',  sanitize_text_field($_POST['lastname'] ) );
    /*wp_new_user_notification( $user_id,'','user' );*/

        if($user_id && is_numeric($user_id)){

        /*Send admin order notification*/
        $registration = get_field('physician_registration_information_email','option');


        $registrationreplaced = str_replace(

            array('[username]'), 

            array($user_name),

            $registration
        );


        $headers = "From: " . strip_tags(get_field('from_email','option')) . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

        mail(    
            strip_tags(get_field('physician_email_to_send_notification','option')), 
            'New Physician Resource Registration', 
            $registrationreplaced , 
            $headers
        );

        /*End admin order notification*/





        echo json_encode(array('flag'=>'success','message'=>'Your account has been successfully created.','redirecturl'=> get_field('registration_redirect_url','option') ));
        }else{

            echo json_encode(array('flag'=>'failure','message'=>'There was problem creating account please try after some time.','redirecturl'=>'' ));
        }

    }


    die; 
}
/*Physician Registration*/