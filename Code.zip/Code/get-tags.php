<h2 class="headding-two">Tags</h2>
<ul class="teg-links">

<?php
        // "blogtag" slug of Tag taxonomy 
    $tax_tags = get_terms(array('blogtag'));
    //print_r($tax_tags);
    foreach($tax_tags as $tag) {

    $tagName = $tag->name; 
    $tagSlug = $tag->slug;
?>                               
   <li><a href="<?php echo get_term_link($tagSlug,'blogtag'); ?>"><?php echo $tagName; ?></a></li>                       
           
<?php }  ?>

</ul>


<!-- GET STICKY POSTS AND TAGS ON ARCHIVE.PHP -->


<?php

$query_obj = get_queried_object();
//print_r($query_obj);
$trm_id = $query_obj->term_id;
$cat_name = $query_obj->name;
$cat_slug = $query_obj->slug;
$taxo = $query_obj->taxonomy;

?>


<?php

$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

//$sticky = get_option('sticky_posts');
$args = array(
          'post_type' => 'post',
          'showposts'=>4,
          'paged' => $paged ,
          'tax_query' => array(
              array(
                  'taxonomy' => $taxo ,
                  'field' => 'slug',
                  'terms' => $cat_slug
              )
          )
      );
$wp_query = new WP_Query( $args );

if($wp_query->have_posts()) : while($wp_query->have_posts()) : $wp_query->the_post();

$postImg = wp_get_attachment_url(get_post_thumbnail_id($post->ID));
?>

                    	<div class="col-md-6 col-sm-6 col-xs-12">
                        	<div class="blog-box">
                                <figure><a href="<?php the_permalink();?>"><img src="<?php echo $postImg ;?>" /></a></figure>	
                                <h1><a href="#"><?php the_title();?></a></h1>
                                <div class="share-area">
                                <?php $date  = get_the_date();                        
		                         $getDate = date('M d, Y', strtotime( $date ));
		                        ?>
                                    <div class="share-left"><?php echo $getDate;?> <a href="#">Comments</a></div>
                                    
                                    <div class="clr"></div>
                                </div>
                                <p><?php the_excerpt();?></p>
                                <p><a href="<?php the_permalink();?>">Read More</a></p>	         
                                
                                <div class="clr"></div>
                            </div>
                        </div>

 <?php endwhile; ?>

                        
                    </div>
                    
                     <div class="clr"></div>
                                       
<?php 
    if(function_exists('wp_paginate')){
        wp_paginate();
     }         
?>  

<?php endif; wp_reset_query();?>   



<!-- you can use this method also -->


<?php

$query_obj = get_queried_object();
//print_r($query_obj);
$trm_id = $query_obj->term_id;
$cat_name = $query_obj->name;
$cat_slug = $query_obj->slug;
$taxo = $query_obj->taxonomy;

?>

<?php

$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

$sticky = get_option('sticky_posts');
//print_r($sticky);
$args = array(
		    'post_type' => 'post',		      
		    'tax_query' => array(
		        array(
		            'taxonomy' => $cat_slug,
		            'field' => 'slug',
		            'terms' => $cat_slug
			        )
			    )
			);

query_posts($args);

if(have_posts()) : while(have_posts()) : the_post();

$postImg = wp_get_attachment_url(get_post_thumbnail_id($post->ID));
?>


<!--  get tags by another method -->
<?php

$tag = get_queried_object();
$post_tag = $tag->slug;
$the_query = new WP_Query( 'tag='.$post_tag );

if ( $the_query->have_posts() ) :  while ( $the_query->have_posts() ) :  $the_query->the_post();
    echo '<li>' . get_the_title() . '</li>';    
    echo '</ul>';
  endwhile; endif; wp_reset_postdata();
?>

<!-- //////////////////////// -->