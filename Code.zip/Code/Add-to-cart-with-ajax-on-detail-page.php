<?php
 /* Start add to cart with ajax on detail page for simple product   */

$(".single_add_to_cart_button.custom-simple-btn").on('click', function(e) {

  e.preventDefault();

  var quantity = $('input[name="quantity"]').val(),
      button = $(this),
      product_id = $(this).val();

  if(quantity > 0){ 

  // Optional, will disable and change text of add to cart button on click 
  //button.prop('disabled', true).text('Adding...');
  button.prop('disabled', true).addClass('loading');


  $.ajax({   
    url: wc_add_to_cart_params.ajax_url,
    type: 'POST',
    data: 'action=mb_wc_add_cart&product_id=' + product_id + '&quantity=' + quantity,
    timeout: 10000,   

    success: function() {
                $(document.body).trigger('wc_fragment_refresh');
                $(document.body).trigger('added_to_cart');

                //$('.woocommerce-notices-wrapper').empty();

                //$('<div class="woocommerce-message" role="alert">Product has been added to your cart.</div>' ).appendTo( '.woocommerce-notices-wrapper' );

                setTimeout(function() {
                    //button.prop('disabled', false).text('Add to Cart');
                    button.prop('disabled', false).removeClass('loading');
                }, 200);
    },
    error: function(xhr, ajaxOptions, thrownError) {
      console.log(xhr.status);
      console.log(thrownError);
    }

  });

} 

});




/* Start add to cart with ajax on detail page for simple product   */

add_action('wp_ajax_mb_wc_add_cart', 'mb_wc_add_cart_ajax');
add_action('wp_ajax_nopriv_mb_wc_add_cart', 'mb_wc_add_cart_ajax');

function mb_wc_add_cart_ajax() {

  $product_id = (int) $_POST['product_id'];
  $quantity = ($_POST['quantity']) ? (int) $_POST['quantity'] : 1; 
  if ($product_id) {
    WC()->cart->add_to_cart( $product_id, $quantity);
  }
  exit();
}