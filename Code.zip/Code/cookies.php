<script>
/*Cookie Game*/
function setCookie(name,value,days) {

var expires = "";
if (days) {
    var date = new Date();
    date.setTime(date.getTime() + (days*24*60*60*1000));
    expires = "; expires=" + date.toUTCString();
}

document.cookie = name + "=" + (value || "")  + expires + "; path=/";
//window.location.href = object_name.legal_drinking_age_url;
}

function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}

function eraseCookie(name) {   
    document.cookie = name+'=; Max-Age=-99999999;';  
}
/*Cookie Game End*/
</script>  


/************************************************************/

<?php 
    if($_GET['channel_id']!=''){

    if(have_rows('channel_lists','option')) : while(have_rows('channel_lists','option')) : the_row();

    if( get_sub_field('channel_key','option') == $_GET['channel_id'] ) {
?>

<script>
    setCookie('phonenumber','<?php the_sub_field('channel_value'); ?>',30);
</script>

<?php
        }
        endwhile ; endif;
    }

?>

<script type="text/javascript">
    

jQuery().ready(function(){

console.log(getCookie('phonenumber'));

    if(getCookie('phonenumber')){

        jQuery('#custom-phone').attr('href','tel:' + getCookie('phonenumber') );

        jQuery('#custom-phone-no').text(getCookie('phonenumber'));

    }

});
</script>


<a id="custom-phone" class="header-phone" href="tel:<?php echo get_field('phone_number','option'); ?>"><i class="fas fa-phone"></i>
    <span id="custom-phone-no" class="d-none d-md-inline pl-2"><?php echo get_field('phone_number','option'); ?></span>
</a>  