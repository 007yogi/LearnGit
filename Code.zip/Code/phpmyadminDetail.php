phpmyadmin
user: root
pass: B6E&3AdbQPHG$!NC