<?php

/**
 * Class View_Search
 */
class View_Search extends View_Inline {
	/**
	 * @var string
	 */
	protected $class = "form-search";
}	
