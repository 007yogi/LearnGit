<?php

/**
 * Class Element_Range
 */
class Element_Range extends Element_Textbox {
	/**
	 * @var array
	 */
	protected $_attributes = array( "type" => "range" );
}
