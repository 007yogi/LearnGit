jQuery(document).ready(function($){

/*  jQuery('.children li').each(function(){
    jQuery(this).prepend('<input type="checkbox" class="selected-cat" value="">');

    if(jQuery(this).hasClass('current-cat')){
    	console.log(jQuery(this).find('a').text());

    	jQuery(this).find('.selected-cat').attr('checked',true);
    }
  });
  
   jQuery('.selected-cat').click(function(){
        if(jQuery(this).is(':checked')){
          location.href = jQuery(this).siblings('a').attr('href');
        }
        else{
          location.href = jQuery(this).siblings('a').attr('href');
        }
    })*/

    /*=============21-01-2020=============================*/
    jQuery(".woocommerce .blog-row").prepend("<div class='sidebar'><span></span><span></span><span></span></div>");

    jQuery(".sidebar").on('click', function() {
      jQuery('.sidebar').toggleClass('active');
    })







/* Start add to cart with ajax on detail page for simple product   */

/*$(".single_add_to_cart_button.custom-simple-btn").on('click', function(e) {

  e.preventDefault();

  var quantity = $('input[name="quantity"]').val(),
      button = $(this),
      product_id = $(this).val();

  if(quantity > 0){ 

  // Optional, will disable and change text of add to cart button on click 
  //button.prop('disabled', true).text('Adding...');
  button.prop('disabled', true).addClass('loading');


  $.ajax({   
    url: wc_add_to_cart_params.ajax_url,
    type: 'POST',
    data: 'action=mb_wc_add_cart&product_id=' + product_id + '&quantity=' + quantity,
    timeout: 10000,   

    success: function() {
                $(document.body).trigger('wc_fragment_refresh');
                $(document.body).trigger('added_to_cart');

                $('.woocommerce-notices-wrapper').empty();

                $('<div class="woocommerce-message" role="alert">Product has been added to your cart.</div>' ).appendTo( '.woocommerce-notices-wrapper' );

                setTimeout(function() {
                    //button.prop('disabled', false).text('Add to Cart');
                    button.prop('disabled', false).removeClass('loading');
                }, 200);
    },
    error: function(xhr, ajaxOptions, thrownError) {
      console.log(xhr.status);
      console.log(thrownError);
    }

  });

} 

});*/





/* start js for change quantity input style */

/*if ( ! String.prototype.getDecimals ) {
    String.prototype.getDecimals = function() {
        var num = this,
            match = ('' + num).match(/(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);
        if ( ! match ) {
            return 0;
        }
        return Math.max( 0, ( match[1] ? match[1].length : 0 ) - ( match[2] ? +match[2] : 0 ) );
    }
}
// Quantity "plus" and "minus" buttons
$( document.body ).on( 'click', '.plus, .minus', function() {
    var $qty        = $( this ).closest( '.quantity' ).find( '.qty'),
        currentVal  = parseFloat( $qty.val() ),
        max         = parseFloat( $qty.attr( 'max' ) ),
        min         = parseFloat( $qty.attr( 'min' ) ),
        step        = $qty.attr( 'step' );

    // Format values
    if ( ! currentVal || currentVal === '' || currentVal === 'NaN' ) currentVal = 0;
    if ( max === '' || max === 'NaN' ) max = '';
    if ( min === '' || min === 'NaN' ) min = 0;
    if ( step === 'any' || step === '' || step === undefined || parseFloat( step ) === 'NaN' ) step = 1;

    // Change the value
    if ( $( this ).is( '.plus' ) ) {
        if ( max && ( currentVal >= max ) ) {
            $qty.val( max );
        } else {
            $qty.val( ( currentVal + parseFloat( step )).toFixed( step.getDecimals() ) );
        }
    } else {
        if ( min && ( currentVal <= min ) ) {
            $qty.val( min );
        } else if ( currentVal > 0 ) {
            $qty.val( ( currentVal - parseFloat( step )).toFixed( step.getDecimals() ) );
        }
    }

    // Trigger change event
    $qty.trigger( 'change' );
});*/

/* endstart js for change quantity input */














   
});



