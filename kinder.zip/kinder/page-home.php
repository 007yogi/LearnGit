<?php

    // Template Name: Home Page

get_header();
?>

<div class="home-wrap">

    <div class="home-banner">
        <div class="container">
            <div class="banner-slider">

            	<?php if(have_rows('banner_slider')) : while(have_rows('banner_slider')) : the_row() ; ?>

                <div class="slide-box">
                    <div class="img-sec" data-aos="fade-up">
                    	<?php $banner_img = get_sub_field('slide_image'); 
                    		if(is_array($banner_img)) {
                    	?>
                        <img src="<?php echo $banner_img['url'] ;?>">
                    <?php } ?>

                    </div>
                    <div class="txt-sec">
                        <h1  data-aos="fade-up" data-aos-delay="300"><?php the_sub_field('slide_title'); ?></h1>
                        <p  data-aos="fade-up" data-aos-delay="500"><?php the_sub_field('slide_content'); ?></p>
                        <a href="<?php the_sub_field('check_out_url');?>" class="btn btn-purpal"  data-aos="fade-up" data-aos-delay="700">Check it Out</a>
                    </div>
                </div>

                <?php endwhile; endif; wp_reset_query(); ?>            


            </div>
            <!--banner-slider-->
        </div>
        <!--container-->
    </div>
    <!--home-banner-->


    <div class="sell-slider">
        <div class="container">
            <div class="heading" data-aos="fade-up">
                <h2 class="h-heading"><?php echo get_the_category_by_ID('25')?></h2>
            </div>

            <div class="slide-content sell-slide-content" data-aos="fade-up" data-aos-delay="300">

                    <?php 
                    /* Get best seller products */

                            $query_args = array(
                                'post_type' => 'product',
                                'post_status' => 'publish',
                                'posts_per_page' => '5',
                                'columns' => '4',
                                'fields' => 'ids',
                                'meta_key' => 'total_sales',
                                'orderby' => 'meta_value_num',
                                'meta_query' => WC()->query->get_meta_query()
                            );

                        $best_sell_products_query = query_posts($query_args); 

                        if(have_posts()) : while(have_posts()) : the_post() ;
                        $pro_image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'single-post-thumbnail' );  
                    ?>

                <div>
                    <div class="slide-box"> 

                        <?php global $product; ?> 

                        <div class="img-box">
                             <?php if ( ! $product->managing_stock() && ! $product->is_in_stock() ) {
                                    echo '<p class="sold-out">Sold Out</p>';
                                }
                            ?>
                            <img src="<?php echo $pro_image[0]; ?>">
                        </div>

                       <div class="txt-box">
                            <a href="<?php the_permalink();?>"><p class="title"><?php the_title();?></p></a>
                            <div class="txt-box-btn">

                            <?php $tags = get_the_terms( get_the_ID(), 'product_tag' ); 
                            if(!empty($tags)) {
                            ?>

                            <?php foreach($tags as $tag) {  
                                $tagName = $tag->name; 
                                $tagSlug = $tag->slug;
                                $tag_link = get_term_link( $tag );
                            ?>
                            <a href="<?php echo get_term_link($tag); ?>"><?php print_r($tagName); ?></a>

                            <?php } } ?>

                            </div>
                            <div class="txt-price"> 
                                <?php                               
                                    $regular_price = get_post_meta( get_the_ID(), '_regular_price', true);  
                                    //$sale_price = get_post_meta( get_the_ID(), '_sale_price', true);  
                                    $currency_symbol =  get_woocommerce_currency_symbol();                          
                                ?>
                                <p><span class="price"><?php echo $currency_symbol;?><?php echo $regular_price;?></span>Free Shipping (USA)</p>
                            </div>
                        </div> 

                    </div>
                    <!--slide-box-->
                </div>

                <?php endwhile; endif; wp_reset_query(); ?>

            </div>
            <!--slide-content-->

        </div>
    </div>
    <!--sell slider-->

    <!--  template part for 'ordering school'  -->
    <?php get_template_part( 'template-parts/content', 'ordering-your-school' ); ?>



    <div class="sell-slider">
        <div class="container">
            <div class="heading" data-aos="fade-up">
                <h2 class="h-heading"><?php echo get_the_category_by_ID('26')?></h2>
            </div>
            <div class="slide-content sell-slide-content" data-aos="fade-up" data-aos-delay="300">

				<?php 
					$args = array(
					   'post_type'          => 'product',
					   'post_status'        => 'publish',
					   'show_posts'         => -1,
					   'tax_query'          => array(
					        array(
					            'taxonomy'  => 'product_cat',
					            'field'     => 'slug',
					            'terms'     => array('staff-picks'),
					        )
					   )
					);

					$loop = new WP_Query( $args );				

					if($loop->have_posts()) : while($loop->have_posts()) : $loop->the_post() ;

					$pro_image = wp_get_attachment_image_src( get_post_thumbnail_id( $loop->post->ID ), 'single-post-thumbnail' );					 
					$product_id = $loop->post->ID;
				?>

                <div>
                    <div class="slide-box">
                        <div class="img-box">

                        	<?php if (  $product->managing_stock() &&  $product->is_on_backorder() ) {
	    							echo '<p class="sold-out">Available Upon request</p>';
	    						}
	    					?> 
	    					<!-- <p class="sold-out">Available Upon request</p> -->                       	
                            <img src="<?php echo $pro_image[0]; ?>">
                        </div>
                        <div class="txt-box">
                            <a href="<?php the_permalink();?>"><p class="title"><?php the_title();?></p></a>
                            <div class="txt-box-btn">

                            <?php $tags = get_the_terms( get_the_ID(), 'product_tag' );  
                            if(!empty($tags)) {
                            ?>

                            <?php foreach($tags as $tag) {  
                                $tagName = $tag->name; 
                                $tagSlug = $tag->slug;
                                $tag_link = get_term_link( $tag );
                            ?>
                            <a href="<?php echo get_term_link($tag); ?>"><?php print_r($tagName); ?></a>

                            <?php } } ?>

                            </div>
                            <div class="txt-price">
                           	<?php                        		
								$regular_price = get_post_meta( get_the_ID(), '_regular_price', true);	
								//$sale_price = get_post_meta( get_the_ID(), '_sale_price', true);	
								$currency_symbol =  get_woocommerce_currency_symbol();						    
                        	?>
                                 <p><span class="price"><?php echo $currency_symbol;?><?php echo $regular_price;?></span>Free Shipping (USA)</p>
                            </div>
                        </div>
                    </div>                    
                </div>

                <?php endwhile; endif; wp_reset_query(); ?>

               
            </div>
            <!--slide-content-->
        </div>
    </div>
    <!--sell slider-->


    <?php

    /*Get list-of-woocommerce-sale-products only */

        $query_args = array(
                    'posts_per_page'    => 8,
                    'no_found_rows'     => 1,
                    'post_status'       => 'publish',
                    'post_type'         => 'product',
                    'meta_query'        => WC()->query->get_meta_query(),
                    'post__in'          => array_merge( array( 0 ), wc_get_product_ids_on_sale() )
                );

            $products = new WP_Query( $query_args );
            $postCount = $products->post_count;

            if($postCount) {

    ?>

    <div class="sell-slider bg-lightgray">
        <div class="container">
            <div class="heading" data-aos="fade-up">
                <h2 class="h-heading"><?php echo get_the_category_by_ID('27')?></h2>
            </div>         

    <div class="slide-content clearance-slider" data-aos="fade-up" data-aos-delay="300">

        <?php 

            if($products->have_posts()) : while($products->have_posts()) : $products->the_post() ;

            $pro_image = wp_get_attachment_image_src( get_post_thumbnail_id( $products->post->ID ), 'single-post-thumbnail' );                   
            $product_id = $products->post->ID;
        ?>

                <div>
                    <div class="slide-box">

                        <div class="img-box">
                            <?php if ( ! $product->managing_stock() && ! $product->is_in_stock() ) {
                                    echo '<p class="sold-out">Sold Out</p>';
                                }
                            ?>
                            <img src="<?php echo $pro_image[0]; ?>">
                        </div>

                        <div class="txt-box">

                            <a href="<?php the_permalink();?>"><p class="title"><?php the_title();?></p></a>                    

                            <div class="txt-box-btn">
                            <?php $tags = get_the_terms( get_the_ID(), 'product_tag' );  
                            if(!empty($tags)) {
                            ?>

                            <?php foreach($tags as $tag) {  
                                $tagName = $tag->name; 
                                $tagSlug = $tag->slug;
                                $tag_link = get_term_link( $tag );
                            ?>
                            <a href="<?php echo get_term_link($tag); ?>"><?php print_r($tagName); ?></a>

                            <?php } } ?>

                            </div>
                            <div class="txt-price custom-reg-sale-price">
                            <?php                               
                                $regular_price = get_post_meta( get_the_ID(), '_regular_price', true);  
                                $sale_price = get_post_meta( get_the_ID(), '_sale_price', true);  
                                $currency_symbol =  get_woocommerce_currency_symbol();  

                                $price_html = $product->get_price_html() ;                    
                            ?>
                                <p class="price-html"><span class="price"><?php echo $price_html; ?></span></p>
                                <p class="free-ship">Free Shipping (USA)</p>
                            </div>

                        </div>
                    </div>
                    <!--slide-box-->
                </div>

        <?php endwhile; endif; wp_reset_query(); ?>

    </div>
    <!--slide-content-->

        </div>
    </div>
    <!--sell slider-->

<?php } ?>

</div>

<?php
 get_footer();