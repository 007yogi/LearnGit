<?php
/**
 * developer_pro functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package developer_pro
 */

if ( ! function_exists( 'developer_pro_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function developer_pro_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on developer_pro, use a find and replace
		 * to change 'developer_pro' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'developer_pro', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'developer_pro' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'developer_pro_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );


		add_image_size( 'custom-blog-img-size', 244, 162 ,true );

	}
endif;
add_action( 'after_setup_theme', 'developer_pro_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function developer_pro_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'developer_pro_content_width', 640 );
}
add_action( 'after_setup_theme', 'developer_pro_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function developer_pro_widgets_init() {

	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'developer_pro' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'developer_pro' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );


	register_sidebar( array(
		'name'          => esc_html__( 'Footer One', 'developer_pro' ),
		'id'            => 'footer-one',
		'description'   => esc_html__( 'Add widgets here.', 'developer_pro' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<ul class="footer-menu-heading"><li>',
		'after_title'   => '</li></ul>',
	) );


	register_sidebar( array(
		'name'          => esc_html__( 'Footer Two', 'developer_pro' ),
		'id'            => 'footer-two',
		'description'   => esc_html__( 'Add widgets here.', 'developer_pro' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<ul class="footer-menu-heading"><li>',
		'after_title'   => '</li></ul>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Footer Three', 'developer_pro' ),
		'id'            => 'footer-three',
		'description'   => esc_html__( 'Add widgets here.', 'developer_pro' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<ul class="footer-menu-heading"><li>',
		'after_title'   => '</li></ul>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Footer Four', 'developer_pro' ),
		'id'            => 'footer-four',
		'description'   => esc_html__( 'Add widgets here.', 'developer_pro' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<ul class="footer-menu-heading"><li>',
		'after_title'   => '</li></ul>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Footer Five', 'developer_pro' ),
		'id'            => 'footer-five',
		'description'   => esc_html__( 'Add widgets here.', 'developer_pro' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<ul class="footer-menu-heading"><li>',
		'after_title'   => '</li></ul>',
	) );


	register_sidebar( array(
		'name'          => esc_html__( 'Footer Six', 'developer_pro' ),
		'id'            => 'footer-six',
		'description'   => esc_html__( 'Add widgets here.', 'developer_pro' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<ul class="footer-menu-heading"><li>',
		'after_title'   => '</li></ul>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Posts Tags', 'developer_pro' ),
		'id'            => 'posts-tags',
		'description'   => esc_html__( 'Add widgets here.', 'developer_pro' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<p class="bold aos-init aos-animate" data-aos="fade-up" data-aos-delay="300">',
		'after_title'   => '</p>',
	) );


}
add_action( 'widgets_init', 'developer_pro_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function developer_pro_scripts() {
	wp_enqueue_style( 'developer_pro-style', get_stylesheet_uri() );

	wp_enqueue_style('font-awesome','https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
	wp_enqueue_style('googleapis','https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800&display=swap');
	wp_enqueue_style('slick-carousel','https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css');
	wp_enqueue_style('slick-theme','https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css');
	wp_enqueue_style('style-min', get_template_directory_uri() .'/app/css/style.min.css');
	wp_enqueue_style('aos', get_template_directory_uri() .'/app/css/aos.css');

	//wp_enqueue_script( 'developer_pro-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );
	//wp_enqueue_script( 'developer_pro-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	wp_deregister_script('jquery');

	wp_enqueue_script('jquery','https://code.jquery.com/jquery-3.3.1.min.js',array(),'',true);

	wp_enqueue_script( 'slick-min-js', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js' ,array('jquery'),'1.11.12',true);
	wp_enqueue_script( 'aos-js', get_template_directory_uri() .'/app/js/aos.js' , array(),'',true);
	wp_enqueue_script( 'custom-second-js', get_template_directory_uri() .'/js/custom-second.js' , array(),'',true);

	wp_enqueue_script( 'main-min-js', get_template_directory_uri() .'/app/js/main.min.js' , array('jquery'),'',true);



	/*if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}*/
}
add_action( 'wp_enqueue_scripts', 'developer_pro_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}



/*Theme Option*/
if( function_exists('acf_add_options_page') ) {
	
	acf_add_options_page(array(
		'page_title' 	=> 'Theme General Settings',
		'menu_title'	=> 'Theme Settings',
		'menu_slug' 	=> 'theme-general-settings',
		'capability'	=> 'edit_posts',
		'redirect'		=> false
	));
	
	acf_add_options_sub_page(array(
		'page_title' 	=> 'Theme Header Settings',
		'menu_title'	=> 'Header',
		'parent_slug'	=> 'theme-general-settings',
	));
	
	acf_add_options_sub_page(array(
		'page_title' 	=> 'Theme Footer Settings',
		'menu_title'	=> 'Footer',
		'parent_slug'	=> 'theme-general-settings',
	));

	acf_add_options_sub_page(array(
		'page_title' 	=> 'Theme Header Scripts',
		'menu_title'	=> 'Header Scripts',
		'parent_slug'	=> 'theme-general-settings',
	));

	acf_add_options_sub_page(array(
		'page_title' 	=> 'Theme Footer Scripts',
		'menu_title'	=> 'Footer Scripts',
		'parent_slug'	=> 'theme-general-settings',
	));
	
}
/*End Theme Option*/



/* woocommerce theme support */
function mytheme_add_woocommerce_support() {
    add_theme_support( 'woocommerce' );
}
add_action( 'after_setup_theme', 'mytheme_add_woocommerce_support' );

/*add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );*/


/* remove result count from shop page */
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );

/* remove 'add-to-cart' button on shop page */
remove_action('woocommerce_after_shop_loop_item','woocommerce_template_loop_add_to_cart',10);

remove_action('woocommerce_after_shop_loop_item_title','woocommerce_template_loop_rating',5);


//remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );

/*function abc(){
	//add_action('custom_woocommerce_before_shop_loop','woocommerce_catalog_ordering',5);
	echo "rdytu";
}
add_action('xyz','abc');*/

/* add container class after main div on shop page */
add_action('woocommerce_before_main_content','custom_woocommerce_before_main_content');
function custom_woocommerce_before_main_content(){
	echo '<div class="container">';
}

/* add 'div' on shop page for left & right section */
add_action('woocommerce_before_shop_loop','custom_woocommerce_before_shop_loop');
function custom_woocommerce_before_shop_loop() { ?>

<div class="custom-product-section"><div class="inner-blog-list"><div class="blog-row">
	<div class="blog-left-sec">
		<?php
			//do_action( 'xyz');
			dynamic_sidebar('sidebar-1');		// add left side bar for categories. 

		?>
	</div>
	<div class="blog-right-sec">

<?php }

/* Add product tags text below product title */
add_action('woocommerce_shop_loop_item_title','custom_woocommerce_shop_loop_item_title');
function custom_woocommerce_shop_loop_item_title() { ?>

	<?php $tags = get_the_terms( get_the_ID(), 'product_tag' );  
		if(!empty($tags)) {
	?>

	<div class="txt-box-btn">		
 
        <?php foreach($tags as $tag) {  
            $tagName = $tag->name; 
            $tagSlug = $tag->slug;
            $tag_link = get_term_link( $tag );
        ?> 
        <a href="<?php echo get_term_link($tag); ?>"><?php print_r($tagName); ?></a>

    	<?php } ?> 

    </div>

<?php } }

/* add free shipping text with product 'price'  */
add_action('woocommerce_after_shop_loop_item','custom_woocommerce_after_shop_loop_item_title');
function custom_woocommerce_after_shop_loop_item_title() { ?>
	<div class="txt-price">
        <p>Free Shipping (USA)</p>
    </div>
<?php }



/* Add Author / ISBN NUMBER tab on product */

function custom_product_tabs( $tabs) {
	$tabs['isbn'] = array(
		'label'		=> __( 'Author / ISBN', 'woocommerce' ),
		'target'	=> 'isbn_options',
		'class'		=> array( 'show_if_simple', 'show_if_variable'  ),
	);
	return $tabs;
}
add_filter( 'woocommerce_product_data_tabs', 'custom_product_tabs' );
/**
 * Contents of the author name & isbn number options product tab.
 */
function isbn_options_product_tab_content() {
	global $post;
	
	// Note the 'id' attribute needs to match the 'target' parameter set above
	?><div id='isbn_options' class='panel woocommerce_options_panel'><?php
		?><div class='options_group'><?php

			woocommerce_wp_text_input( array(
				'id'				=> 'author_name',
				'label'				=> __( 'Author Name', 'woocommerce' ),
				'desc_tip'			=> 'true',
				'description'		=> __( 'Please Insert Author Name.', 'woocommerce' ),
				'type' 				=> 'text',
				
			) );
			
			woocommerce_wp_text_input( array(
				'id'				=> 'isbn_number',
				'label'				=> __( 'ISBN Number', 'woocommerce' ),
				'desc_tip'			=> 'true',
				'description'		=> __( 'Please add ISBN Number.', 'woocommerce' ),
				'type' 				=> 'text',
				
			) );			

		?></div>

	</div><?php
}
#add_filter( 'woocommerce_product_data_tabs', 'isbn_options_product_tab_content' ); // WC 2.5 and below
add_filter( 'woocommerce_product_data_panels', 'isbn_options_product_tab_content' ); // WC 2.6 and up
/**
 * Save the custom fields.
 */
function save_isbn_options_option_fields( $post_id ) {
	
	if ( isset( $_POST['isbn_number'] ) || isset( $_POST['author_name'] ) ) :

		update_post_meta( $post_id, 'author_name', $_POST['author_name'] );  
		update_post_meta( $post_id, 'isbn_number', absint( $_POST['isbn_number'] ) );
	endif;
	
}
add_action( 'woocommerce_process_product_meta_simple', 'save_isbn_options_option_fields'  );
add_action( 'woocommerce_process_product_meta_variable', 'save_isbn_options_option_fields'  );

/* End Author / ISBN NUMBER*/


/* change the postion of "price" & star-rating */
remove_action('woocommerce_single_product_summary','woocommerce_template_single_price',10);
remove_action('woocommerce_single_product_summary','woocommerce_template_single_rating',10);

add_action('woocommerce_single_product_summary','woocommerce_template_single_price',10);
add_action('woocommerce_single_product_summary','woocommerce_template_single_rating',15);

/* Add the products tags after the product title on detail page */
add_action( 'woocommerce_single_product_summary', 'custom_action_after_single_product_title', 6 );
function custom_action_after_single_product_title() { ?>

	<?php $tags = get_the_terms( get_the_ID(), 'product_tag' );
		if(!empty($tags)) {
	?>	

    <div class="txt-box-btn">	
         <?php foreach($tags as $tag) {  
            $tagName = $tag->name; 
            $tagSlug = $tag->slug;
            $tag_link = get_term_link( $tag );
        ?> 
        <a href="<?php echo get_term_link($tag); ?>"><?php print_r($tagName); ?></a>
    	<?php } ?>

    </div>

<?php } }


/* change the postion of 'add-to-card' button & 'short-description' on detail page */
remove_action('woocommerce_single_product_summary','woocommerce_template_single_excerpt',20);
remove_action('woocommerce_single_product_summary','woocommerce_template_single_add_to_cart',30);

add_action('woocommerce_single_product_summary','woocommerce_template_single_excerpt',30);
add_action('woocommerce_single_product_summary','woocommerce_template_single_add_to_cart',20);

/* remove the tags from detail page after 'short descripton '*/
remove_action('woocommerce_single_product_summary','woocommerce_template_single_meta',40);


// Adds the new tab 'More Information'
add_filter( 'woocommerce_product_tabs', 'woo_new_product_tab' );
function woo_new_product_tab( $tabs ) {

    $tabs['desc_tab'] = array(
        'title'     => __( 'More Information', 'woocommerce' ),
        'priority'  => 50,
        'callback'  => 'woo_new_product_tab_content'
    );
    return $tabs;
}

  // The new tab content
function woo_new_product_tab_content() {
  global $product;  
  $prod_id = get_the_ID();

 	echo '<div class="custom-author-title flex"><span>Author: </span><p>' . get_post_meta($prod_id,'author_name',true) . '</p></div>'; 

 	echo '<div class="custom-author-title flex"><span>ISBN: </span><p>' . get_post_meta($prod_id,'isbn_number',true) . '</p></div>'; 

 	$weight_unit = get_option('woocommerce_weight_unit');
	echo '<div class="custom-author-title flex"><span>Weight: </span><p>' . $product->get_weight() . $weight_unit . '</p></div>';	
}


/* reorder tabs on detail page */

add_filter( 'woocommerce_product_tabs', 'sb_woo_move_description_tab', 98);
function sb_woo_move_description_tab($tabs) {
    $tabs['desc_tab']['priority'] = 5;
    $tabs['reviews']['priority'] = 20;
    return $tabs;
}



/* remove the default tabs from detail page */
add_filter( 'woocommerce_product_tabs', 'woo_remove_product_tabs', 98 );

function woo_remove_product_tabs( $tabs ) {
    unset( $tabs['description'] );          // Remove the description tab
    unset( $tabs['additional_information'] ); 
    return $tabs;
}


/* add template part of 'ordering school'  on detail  page */

add_action('woocommerce_after_single_product_summary','ordering_school',11);
function ordering_school(){
	get_template_part( 'template-parts/content', 'ordering-your-school' );
}


/* add cart detail on checkout page */
add_action('custom_cart_detail_checkout','cart_detail_checkout');

function cart_detail_checkout(){ ?>

<div class="custom-order-wrap custom-checkout-cart-detail">
	<ul class="flex">

	<?php
		foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
		$_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
		$product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

		if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
			$product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
			?>
			<li class="woocommerce-cart-form__cart-item <?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">

				<div class="custom-item-thumbnail">
					<?php
						$thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );

						if ( ! $product_permalink ) {
							echo $thumbnail; // PHPCS: XSS ok.
						} else {
							printf( $thumbnail ); // PHPCS: XSS ok.
						}
					?>
					<?php
						if ( $_product->is_sold_individually() ) {
							$product_quantity = sprintf( '1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key );
						} else {
								echo '<span class="custom-items-qty">'. $cart_item['quantity'] . '</span>';
						}

						echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item ); // PHPCS: XSS ok.
					?>

				</div>

				<div class="custom-product-name" data-title="<?php esc_attr_e( 'Product', 'woocommerce' ); ?>">
					<?php
						if ( ! $product_permalink ) {
							echo '<h3>' . wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) . '&nbsp;' ) . '</h3>';
						} else {
							echo '<h3>' . wp_kses_post( apply_filters( 'woocommerce_cart_item_name', sprintf( $_product->get_name() ), $cart_item, $cart_item_key ) ) . '</h3>';
						}

						do_action( 'woocommerce_after_cart_item_name', $cart_item, $cart_item_key );

						// Meta data.
						echo wc_get_formatted_cart_item_data( $cart_item ); // PHPCS: XSS ok.

						// Backorder notification.
						if ( $_product->backorders_require_notification() && $_product->is_on_backorder( $cart_item['quantity'] ) ) {
							echo wp_kses_post( apply_filters( 'woocommerce_cart_item_backorder_notification', '<p class="backorder_notification">' . esc_html__( 'Available on backorder', 'woocommerce' ) . '</p>', $product_id ) );
						}
					?>					
					<?php
						echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); // PHPCS: XSS ok.
					?>
				</div>

			</li>
			<?php
			}
		} 
	?>
	</ul>
</div>
<?php }

/* End add cart detail on checkout page */


/* add cart bag qantity with ajax */
add_filter( 'woocommerce_add_to_cart_fragments', 'woocommerce_header_add_to_cart_fragment' );
function woocommerce_header_add_to_cart_fragment( $fragments ) {
    ob_start();
    ?>

   <a class="cart-contents" href="<?php echo wc_get_cart_url(); ?>">
   		<img src="<?php echo get_template_directory_uri(); ?>/app/images/Icon awesome-shopping-bag.png"><span><?php echo WC()->cart->get_cart_contents_count(); ?></span>
   </a>   
  
    <?php
    $fragments['a.cart-contents'] = ob_get_clean();
    return $fragments;
}


/* Start add to cart with ajax on detail page for simple product   */

add_action('wp_ajax_mb_wc_add_cart', 'mb_wc_add_cart_ajax');
add_action('wp_ajax_nopriv_mb_wc_add_cart', 'mb_wc_add_cart_ajax');

function mb_wc_add_cart_ajax() {

  $product_id = (int) $_POST['product_id'];
  $quantity = ($_POST['quantity']) ? (int) $_POST['quantity'] : 1; 
  if ($product_id) {
    WC()->cart->add_to_cart( $product_id, $quantity);
  }
  exit();
}


/**********************************Add affiliates related code****************************************************/


	add_action( 'woocommerce_thankyou', 'add_referal_id_and_save_in_save_user_meta');
 
		function add_referal_id_and_save_in_save_user_meta( $order_id ) {
		    
		   $order = wc_get_order( $order_id );
		   $user_id = $order->get_user_id();
		    
		   if ( $order->get_total() > 0 ) {  // Define your condition here
		      update_user_meta( $user_id, 'referal_id', $_COOKIE["Userid"]);
		   }
		 
		}



		add_action('woocommerce_add_order_item_meta','wdm_add_values_to_order_item_meta',1,2);
		if(!function_exists('wdm_add_values_to_order_item_meta'))
		{
		  function wdm_add_values_to_order_item_meta($item_id, $values)
		  {
		        global $woocommerce,$wpdb;
		        $user_custom_values = $_COOKIE["Userid"];
		        if(!empty($user_custom_values))
		        {
		            wc_add_order_item_meta($item_id,'referal_id',$user_custom_values);  
		        }
		  }
		}
/*************End of code**************************************************************************/

/*******************Add referal id in order listing********************************************/
	add_filter( 'manage_edit-shop_order_columns', 'custom_shop_order_column', 20 );
			function custom_shop_order_column($columns)
			{
			    $reordered_columns = array();
			    global $the_order, $post;

			    // Inserting columns to a specific location
			    foreach( $columns as $key => $column){
			        $reordered_columns[$key] = $column;
			        if( $key ==  'order_status' ){
			            
			            $reordered_columns['referal_id'] = __( 'Referal Id','theme_domain');
			            $reordered_columns['commission'] = __( 'Commission','theme_domain');
			            $reordered_columns['reset'] = __( 'Reset commission','theme_domain');
			            
			        }

			    }
			    return $reordered_columns;
			}
/*******************************Reset order referral id***************************/
		if(!empty($_GET['order_id']))
		{
			echo 'order id'. $_GET['order_id'];
		}
// Adding custom fields meta data for each new column (example)
	add_action( 'manage_shop_order_posts_custom_column' , 'custom_orders_list_column_content', 20, 2 );
			function custom_orders_list_column_content( $column, $post_id )
			{
			    switch ( $column )
			    {
			        case 'referal_id' :
			        global $the_order, $post;
			            // Get custom post meta data
			            //$my_var_one = get_post_meta( $post_id, 'referal_id', true );
			        global $post;
					$order = wc_get_order( $post->ID );
					$items = $order->get_items(); 

					foreach ( $order->get_items() as $item_id => $item ) {

					    // Here you get your data
					    $custom_field = wc_get_order_item_meta( $item_id, 'referal_id', true ); 

					    // To test data output (uncomment the line below)
					    // print_r($custom_field);

					    // If it is an array of values
					    if( is_array( $custom_field ) ){
					        echo implode( '<br>', $custom_field ); // one value displayed by line 
					    } 
					    // just one value (a string)
					    else {
					        //echo $custom_field;
					    }
					}
			            if(!empty($custom_field))
			                echo $custom_field;

			            // Testing (to be removed) - Empty value case
			            else
			                echo '<small>(<em>no value</em>)</small>';

			            break;

			            case 'commission' :
				       
				        //global $post;
				        global $the_order, $post;
						//$order = wc_get_order( $post->ID );
						//$item_total = wc_get_order( $order_id ); 
						$order_items = $the_order->get_items();
						//print_r($order_items);
				            if(!empty($order_items))
				            { foreach($order_items as $data)
				            	{
				            		$total =  $data['total'];
				            		$commission  = $total / 10;
				            		echo '$'.$commission;
				            	}
				            }else{
				                echo '<small>(<em>no value</em>)</small>';
				                 //echo $order->get_total(); 
				            }

				            break;
				        case 'reset' :
				       
				        //global $post;
					        global $the_order, $post;
							//$order = wc_get_order( $post->ID );
							//$item_total = wc_get_order( $order_id ); 
							$order_items = $the_order->get_items();
							//print_r($order_items);
							global $post;
					            if(!empty($order_items))
					            { foreach($order_items as $data)
					            	{
					            		echo '<a href="'.admin_url().'edit.php?post_type=shop_order&order_id='.$post->ID.'">Reset</a>';
					            	}
					            }else{
					                echo '<small>(<em>no value</em>)</small>';
					                 //echo $order->get_total(); 
					            }

				            break;

			        
			    }
			}

/***********************Add percentage amount on cart total*************************************/
		
		add_filter( 'woocommerce_calculated_total', 'custom_cart_grand_total', 20, 2 );
		function custom_cart_grand_total( $total, $cart ) 
		{
		    return $total * 1.10;
		}

/***********************************************End of code************************************************************/



/* Add An "Affiliate" Link To The My Account Navigation */
function iconic_account_menu_items( $items ) { 
    $items['information'] = __( 'Information', 'iconic' ); 
    return $items; 
} 
add_filter( 'woocommerce_account_menu_items', 'iconic_account_menu_items', 10, 1 );

/* Add A "Affiliate" Endpoint */
function iconic_add_my_account_endpoint() { 
    add_rewrite_endpoint( 'information', EP_PAGES ); 
}
 
add_action( 'init', 'iconic_add_my_account_endpoint' );


/* Add Content To Our New Endpoint */
function iconic_information_endpoint_content() { 
	$userId = get_current_user_id();
	echo 'Affiliate link: ' .home_url('my-account').'/?Userid='.base64_encode($userId);
	//echo 'Test'.$_COOKIE["Userid"];
	global $wpdb;
	
	$table_name = $wpdb->prefix . "woocommerce_order_itemmeta";
	$table_name1 = $wpdb->prefix . "woocommerce_order_items";
	$table_name2 = $wpdb->prefix . "posts";
	 $userId 	 = get_current_user_id();
	 //$get_results = $wpdb->get_results("SELECT * FROM $table_name WHERE meta_key = 'referal_id' and meta_value='3'");
	
	$sql = $wpdb->prepare( "SELECT * FROM $table_name INNER JOIN $table_name1 ON $table_name.order_item_id = $table_name1.order_item_id WHERE $table_name.meta_key = 'referal_id' and $table_name.meta_value='".$userId."'");
	$get_results = $wpdb->get_results($sql);
	//echo "SELECT * FROM $table_name INNER JOIN $table_name1 ON $table_name.order_item_id = $table_name1.order_item_id WHERE $table_name.meta_key = 'referal_id' and $table_name.meta_value='3'";
	?>
	
	<table width="50%">
	  <thead>
	    <tr>
	      <th>Order title</th>
	      <th>Referral Id</th>
	      <th>Commission</th>
	    </tr>
	  </thead>
	  <tbody>
	  	<?php
	
 	foreach ($get_results as $data) {
 		
 		?>
 		<tr>
	      <td>#<?php echo $data->order_id;?></td>
	      <td><?php echo $userId; ?></td>
	      <td><?php echo '$'. get_post_meta( $data->order_id, '_order_total', true ) % 100 ; ?></td>
	    </tr>
 		<?php
 		
 	}
	?>
	
	  </tbody>
  
</table>

<!--a href="<?php //echo home_url('my-account').'&Userid='.base64_encode($userId); ?>" target="_blank">Affiliate link</a-->
<?php } 
add_action( 'woocommerce_account_information_endpoint', 'iconic_information_endpoint_content' );


/* Change the my account menu order */
function my_account_menu_order() {
 	$menuOrder = array(
 		'orders'             => __( 'Orders', 'woocommerce' ),
 		'downloads'          => __( 'Download', 'woocommerce' ),
 		'edit-address'       => __( 'Addresses', 'woocommerce' ),
 		'edit-account'    	=> __( 'Account Details', 'woocommerce' ),
 		'information'          => __( 'Affiliate Link', 'woocommerce' ),
 		'customer-logout'    => __( 'Logout', 'woocommerce' ),
 	);
 	return $menuOrder;
 }

add_filter ( 'woocommerce_account_menu_items', 'my_account_menu_order' );