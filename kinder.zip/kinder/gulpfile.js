
const gulp = require('gulp');
const imagemin = require('gulp-imagemin');
const uglifyJS = require('gulp-uglify');
const concatJS = require('gulp-concat');
const sass= require('gulp-sass');
const rename = require("gulp-rename");
const concatCss = require('gulp-concat-css');
const minifyCss = require('gulp-clean-css');



//scripts
gulp.task('scripts', function() {
    return gulp.src('js/*.js')
      .pipe(concatJS('main.js'))
      .pipe(rename({
        suffix:'.min'
      }))
      .pipe(uglifyJS())
      .pipe(gulp.dest('app/js'));
});

//sass
gulp.task('styles', function () {
    return gulp.src('scss/**/*.scss')
      .pipe(sass().on('error', sass.logError))
      .pipe(concatCss("style.css"))
      .pipe(rename({
        suffix:'.min'
        }))
      .pipe(minifyCss({compatibility: 'ie8'}))
      .pipe(gulp.dest('app/css'));
});

//imageMin
// gulp.task('imageMin', function(){
//     gulp.src('images/*')
//         .pipe(imagemin())
//         .pipe(gulp.dest('App/images'));
// });


//watch
gulp.task('watch', function(){
    gulp.watch('scss/**/*.scss', ['styles']);
    gulp.watch('js/*.js', ['scripts']);
    gulp.watch('.html');
});


//default
gulp.task('default', ['watch','scripts', 'styles']);